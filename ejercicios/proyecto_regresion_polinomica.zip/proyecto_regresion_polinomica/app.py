"""API Flask de ejemplo para ajuste de regresión polinómica."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
from functools import wraps
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, g, jsonify, request
from itsdangerous import BadSignature, URLSafeTimedSerializer
from werkzeug.exceptions import RequestEntityTooLarge
from dotenv import load_dotenv

from api_functions import (
    parse_csv, parse_json_points, random_forest_options, run_model,
    run_random_forest, validate_reference,
)


# Carga variables locales antes de inicializar el diccionario de usuarios y la
# configuración de caducidad. Las variables ya definidas en el entorno prevalecen.
load_dotenv(Path(__file__).resolve().parent / ".env", override=False)

# Todas las salidas quedan ancladas al proyecto, no al directorio desde el que
# se haya lanzado Flask. Esto evita que un cambio de working directory disperse
# artefactos de una misma ejecución.
OUTPUT_ROOT = Path(__file__).resolve().parent / "runs"
# Diccionario didáctico usuario -> contraseña. Las contraseñas se leen del entorno
# y no se escriben en el repositorio. Añade aquí más pares para otros usuarios.
USERS = {
    "admin": os.environ.get("API_ADMIN_PASSWORD", ""),
}
# Los tokens Bearer caducan tras una hora por defecto.
TOKEN_MAX_AGE_SECONDS = max(1, int(os.environ.get("API_TOKEN_TTL_SECONDS", "3600")))


def create_app(output_root: Path = OUTPUT_ROOT, users: dict | None = None, token_secret: str | None = None) -> Flask:
    app = Flask(__name__)
    output_root = Path(output_root)
    # API_TOKEN_SECRET debe ser estable y secreto en despliegues con varios
    # procesos. El secreto aleatorio permite arrancar el ejemplo localmente; en
    # ese caso los tokens dejan de ser válidos al reiniciar el proceso.
    token_secret = token_secret or os.environ.get("API_TOKEN_SECRET") or secrets.token_urlsafe(32)
    app.config["API_USERS"] = USERS if users is None else users
    app.config["API_TOKEN_MAX_AGE"] = TOKEN_MAX_AGE_SECONDS
    token_serializer = URLSafeTimedSerializer(token_secret, salt="regresion-polinomica-api-token")
    # Registro de auditoría central: incluye también login, health, errores 4xx
    # y rutas inexistentes, no solo las ejecuciones que crean un log por run.
    audit_dir = output_root / "_auditoria"
    audit_dir.mkdir(parents=True, exist_ok=True)
    audit_path = audit_dir / "api_audit.jsonl"
    audit_logger = logging.getLogger(
        "regression.api.audit." + hashlib.sha256(str(audit_path.resolve()).encode()).hexdigest()[:12]
    )
    audit_logger.setLevel(logging.INFO)
    audit_logger.propagate = False
    if not any(getattr(handler, "baseFilename", None) == str(audit_path.resolve())
               for handler in audit_logger.handlers):
        audit_handler = logging.FileHandler(audit_path, encoding="utf-8")
        audit_handler.setFormatter(logging.Formatter("%(message)s"))
        audit_logger.addHandler(audit_handler)
    # Flask rechaza cuerpos excesivos antes de parsearlos; el endpoint CSV aplica
    # además un máximo menor sobre el archivo concreto.
    app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024

    def token_fingerprint(token: str) -> str:
        # Se registra solo una huella SHA-256, nunca el Bearer reutilizable.
        return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]

    @app.before_request
    def capture_request_context():
        authorization = request.headers.get("Authorization", "")
        scheme, separator, supplied_token = authorization.partition(" ")
        g.authenticated_user = None
        g.requested_username = None
        g.client_ip = request.remote_addr or "unknown"
        g.token_fingerprint = (
            token_fingerprint(supplied_token.strip())
            if separator and scheme.lower() == "bearer" and supplied_token.strip()
            else None
        )

    @app.after_request
    def write_audit_log(response):
        # JSONL mantiene una entrada estructurada y evita inyección de líneas en
        # los logs si usuario, ruta o cabeceras contienen caracteres especiales.
        record = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "method": request.method,
            "path": request.path,
            "status": response.status_code,
            "username": (getattr(g, "authenticated_user", None)
                         or getattr(g, "requested_username", None) or "anonymous"),
            "token_fingerprint": getattr(g, "token_fingerprint", None),
            "client_ip": getattr(g, "client_ip", None),
        }
        audit_logger.info(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
        return response

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_error):
        return jsonify(error="El cuerpo supera el límite de 5 MB."), 413

    @app.post("/api/v1/auth/token")
    def issue_token():
        # El endpoint de autenticación es público; solo emite un token cuando
        # el par usuario/contraseña coincide con el diccionario configurado.
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return jsonify(error="El cuerpo debe ser un objeto JSON."), 400
        username = body.get("username")
        password = body.get("password")
        if isinstance(username, str):
            g.requested_username = username
        if not isinstance(username, str) or not isinstance(password, str):
            return jsonify(error="username y password son obligatorios."), 400
        expected_password = app.config["API_USERS"].get(username)
        # compare_digest reduce diferencias de tiempo al comparar contraseñas.
        valid = (
            isinstance(expected_password, str)
            and bool(expected_password)
            and hmac.compare_digest(expected_password.encode("utf-8"), password.encode("utf-8"))
        )
        if not valid:
            return jsonify(error="Credenciales no válidas."), 401
        token = token_serializer.dumps({"sub": username})
        # La llamada de login también queda asociada a usuario y huella del
        # token recién emitido, sin registrar el valor secreto del token.
        g.authenticated_user = username
        g.token_fingerprint = token_fingerprint(token)
        return jsonify(
            access_token=token,
            token_type="Bearer",
            expires_in=app.config["API_TOKEN_MAX_AGE"],
        ), 200

    def require_token(view):
        # Protege las rutas de entrenamiento sin duplicar la validación del token.
        @wraps(view)
        def wrapped(*args, **kwargs):
            authorization = request.headers.get("Authorization", "")
            scheme, separator, token = authorization.partition(" ")
            if not separator or scheme.lower() != "bearer" or not token.strip():
                response = jsonify(error="Se requiere Authorization: Bearer <token>.")
                response.status_code = 401
                response.headers["WWW-Authenticate"] = "Bearer"
                return response
            try:
                claims = token_serializer.loads(
                    token.strip(), max_age=app.config["API_TOKEN_MAX_AGE"]
                )
            except BadSignature:
                response = jsonify(error="Token inválido o caducado.")
                response.status_code = 401
                response.headers["WWW-Authenticate"] = "Bearer"
                return response
            username = claims.get("sub") if isinstance(claims, dict) else None
            current_password = app.config["API_USERS"].get(username) if isinstance(username, str) else None
            if not isinstance(current_password, str) or not current_password:
                response = jsonify(error="Token inválido o caducado.")
                response.status_code = 401
                response.headers["WWW-Authenticate"] = "Bearer"
                return response
            g.authenticated_user = username
            return view(*args, **kwargs)
        return wrapped

    @app.get("/api/v1/health")
    def health():
        return jsonify(status="ok", service="regresion-polinomica-api", version="1.0.0")

    @app.post("/api/v1/regresion/polinomica")
    @require_token
    def fit_json():
        # `silent=True` permite devolver un 400 uniforme para JSON mal formado,
        # en lugar de que el detalle interno del parser llegue al cliente.
        body = request.get_json(silent=True)
        if not isinstance(body, dict):
            return jsonify(error="El cuerpo debe ser un objeto JSON."), 400
        reference, error = validate_reference(body.get("reference"))
        if error:
            return jsonify(error=error), 400
        # El grado controla la complejidad y estabilidad del ajuste. Se limita
        # antes de construir el modelo para evitar modelos excesivamente flexibles.
        degree = body.get("degree", 2)
        if isinstance(degree, bool) or not isinstance(degree, int) or degree < 1 or degree > 10:
            return jsonify(error="degree debe ser un entero entre 1 y 10."), 400
        points = body.get("data")
        try:
            x, y = parse_json_points(points)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        return run_model(app, output_root, reference, degree, x, y, "json")

    @app.post("/api/v1/regresion/polinomica/csv")
    @require_token
    def fit_csv():
        # Multipart separa los parámetros de control del fichero binario y es el
        # formato que Postman usa para adjuntar CSV sin codificarlo en JSON.
        reference, error = validate_reference(request.form.get("reference"))
        if error:
            return jsonify(error=error), 400
        try:
            degree = int(request.form.get("degree", "2"))
        except (TypeError, ValueError):
            return jsonify(error="degree debe ser un entero entre 1 y 10."), 400
        if not 1 <= degree <= 10:
            return jsonify(error="degree debe ser un entero entre 1 y 10."), 400
        uploaded = request.files.get("file")
        if uploaded is None or not uploaded.filename:
            return jsonify(error="Falta el archivo CSV en el campo multipart 'file'."), 400
        # Se lee una sola vez y se controla el tamaño antes de decodificarlo; luego
        # se conserva el original recibido como rastro reproducible de la entrada.
        raw = uploaded.read()
        if len(raw) > 4 * 1024 * 1024:
            return jsonify(error="El CSV supera el límite de 4 MB."), 413
        try:
            text = raw.decode("utf-8-sig")
            x, y = parse_csv(text)
        except (UnicodeDecodeError, ValueError) as exc:
            return jsonify(error=f"CSV no válido: {exc}"), 400
        return run_model(app, output_root, reference, degree, x, y, "csv", raw_csv=raw)

    @app.post("/api/v1/random-forest/terrazas")
    @require_token
    def fit_random_forest_terraces():
        # Emplea el CSV versionado en ejemplos para reproducir la práctica sin subir fichero.
        body = request.get_json(silent=True)
        if body is None:
            body = {}
        if not isinstance(body, dict):
            return jsonify(error="El cuerpo debe ser un objeto JSON."), 400
        reference, error = validate_reference(body.get("reference"))
        if error:
            return jsonify(error=error), 400
        try:
            options = random_forest_options(body)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        sample_path = Path(__file__).resolve().parent / "ejemplos" / "datos_ejemplo_complejo.csv"
        if not sample_path.is_file():
            return jsonify(error="No está disponible el CSV de ejemplo complejo."), 500
        return run_random_forest(app, output_root, reference, sample_path.read_bytes(), options,
                                 "datos_ejemplo_complejo.csv")

    @app.post("/api/v1/random-forest/csv")
    @require_token
    def fit_random_forest_csv():
        # Ruta multipart para entrenar con un CSV del cliente usando el mismo pipeline.
        reference, error = validate_reference(request.form.get("reference"))
        if error:
            return jsonify(error=error), 400
        try:
            options = random_forest_options(request.form)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        uploaded = request.files.get("file")
        if uploaded is None or not uploaded.filename:
            return jsonify(error="Falta el archivo CSV en el campo multipart 'file'."), 400
        raw = uploaded.read()
        if len(raw) > 4 * 1024 * 1024:
            return jsonify(error="El CSV supera el límite de 4 MB."), 413
        return run_random_forest(app, output_root, reference, raw, options, uploaded.filename)

    return app
















app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
