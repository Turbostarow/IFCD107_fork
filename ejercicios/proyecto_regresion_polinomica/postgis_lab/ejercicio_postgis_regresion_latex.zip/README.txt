PROYECTO LATEX: POSTGIS Y REGRESORES LINEALES

Archivo principal: main.tex. Codificacion UTF-8.
Compilar desde esta carpeta con:
  tectonic main.tex
o dos veces con:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex

Overleaf: subir el ZIP, seleccionar main.tex como documento principal y pdfLaTeX.
La carpeta referencia debe conservarse para incluir las consultas del apendice.

El documento explica el laboratorio ejecutable situado en:
D:\onedrive\Documentos\ChatGPT\ifcd107\ejercicios\proyecto_regresion_polinomica
Desde esa carpeta: docker compose up -d --build postgis-lab postgis-lab-ui
Interfaz: http://localhost:8502

El ZIP es documental e incluye copias de referencia de la solucion.
El compose.yaml principal incluye postgis_lab/compose.yaml (Compose 2.20+).
referencia/compose.yaml conserva la definicion modular del laboratorio.
No incluye credenciales del entorno ni datos privados.
