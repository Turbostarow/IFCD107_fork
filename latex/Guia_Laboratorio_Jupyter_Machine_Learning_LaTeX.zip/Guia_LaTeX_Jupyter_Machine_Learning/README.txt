GUÍA LATEX — LABORATORIO JUPYTER DE MACHINE LEARNING

Archivo principal:
Guia_Laboratorio_Jupyter_Machine_Learning.tex

Compilación:
pdflatex Guia_Laboratorio_Jupyter_Machine_Learning.tex
pdflatex Guia_Laboratorio_Jupyter_Machine_Learning.tex

La guía acompaña a:
01_Regresion_Lineal.ipynb
02_Regresion_Polinomica.ipynb
03_Regresion_Logistica.ipynb
04_Kmeans.ipynb
05_KNN.ipynb
06_SVM.ipynb
07_Random_Forest.ipynb
