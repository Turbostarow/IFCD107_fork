# IFCD107 - Tema 1 - Secciones 1 y 2

Presentación Beamer basada en el material docente proporcionado para:

1. Inmersión a la IA explicando sus principales modalidades.
2. Breve noción sobre los principales algoritmos de IA.

## Duración
- Sesión 01: 3 horas
- Sesión 02: 3 horas
- Total: 6 horas

Cada sesión sigue 45 + 45 + 45 + 45 minutos:
- revisión y activación;
- inmersión teórica;
- aplicación práctica;
- presentación y reflexión.

## Compilación
```bash
xelatex main.tex
```

El proyecto utiliza el `ucsbeamer.sty` proporcionado por el usuario y los fondos `layout-01.png` ... `layout-12.png`.
